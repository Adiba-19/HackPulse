let count = parseInt(localStorage.getItem("waterCount")) || 0;
let goal = parseInt(localStorage.getItem("waterGoal")) || 8;
let history = JSON.parse(localStorage.getItem("waterHistory")) || {};
let lastDate = localStorage.getItem("lastDate") || "";
let today = new Date().toLocaleDateString();

// ✅ Auto reset if new day
if (lastDate !== today) {
  if (count > 0 && lastDate) {
    history[lastDate] = count;
    localStorage.setItem("waterHistory", JSON.stringify(history));
  }
  count = 0;
  localStorage.setItem("waterCount", count);
  localStorage.setItem("lastDate", today);
}

// ✅ Initialize UI
document.getElementById("count").textContent = count;
document.getElementById("goal").textContent = goal;
document.getElementById("goalInput").value = goal;
updateProgress();
renderChart();
renderCalendar();

// ✅ Add glass
function addGlass() {
  if (count < goal) {
    count++;
    localStorage.setItem("waterCount", count);
    document.getElementById("count").textContent = count;
    updateProgress();

    if (count === 4) alert("⚠️ You are in unhydration! Drink more water 💧");
    if (count === goal) alert("🎉 Congratulations! Goal reached!");

    renderCalendar();
    renderChart();
  } else {
    alert("✅ Already at your daily goal!");
  }
}

// ✅ Reset tracker
function resetTracker() {
  if (count > 0) {
    history[today] = count;
    localStorage.setItem("waterHistory", JSON.stringify(history));
  }
  count = 0;
  localStorage.setItem("waterCount", count);
  document.getElementById("count").textContent = count;
  updateProgress();
  renderCalendar();
  renderChart();
}

// ✅ Set goal
function setGoal() {
  let newGoal = parseInt(document.getElementById("goalInput").value);
  if (newGoal > 0) {
    goal = newGoal;
    localStorage.setItem("waterGoal", goal);
    document.getElementById("goal").textContent = goal;
    count = 0;
    localStorage.setItem("waterCount", count);
    document.getElementById("count").textContent = count;
    updateProgress();
    renderChart();
    renderCalendar();
  } else {
    alert("⚠️ Please enter a valid goal!");
  }
}

// ✅ Update progress bar
function updateProgress() {
  let percent = (count / goal) * 100;
  document.getElementById("progress-bar").style.width = percent + "%";
}

// ✅ Get last 7 days
function getLast7Days() {
  let days = [];
  for (let i = 6; i >= 0; i--) {
    let d = new Date();
    d.setDate(d.getDate() - i);
    days.push(d.toLocaleDateString());
  }
  return days;
}

// ✅ Chart
function renderChart() {
  let ctx = document.getElementById("historyChart").getContext("2d");
  if (window.historyChart) window.historyChart.destroy();

  let last7Days = getLast7Days();
  let labels = [], data = [];

  last7Days.forEach(day => {
    labels.push(day);
    data.push(history[day] || 0);
  });

  window.historyChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [{
        label: 'Glasses of Water',
        data: data,
        backgroundColor: '#2196f3'
      }]
    },
    options: { responsive: true, scales: { y: { beginAtZero: true } } }
  });
}

// ✅ Calendar
function renderCalendar() {
  let last7Days = getLast7Days();
  let calendarRows = "";

  last7Days.forEach(day => {
    let glasses = history[day] || 0;

    // Color coding
    let rowClass = "";
    if (glasses < 4) rowClass = "low";
    else if (glasses < goal) rowClass = "medium";
    else rowClass = "good";

    calendarRows += `<tr class="${rowClass}" onclick="editDay('${day}')">
      <td>${day}</td>
      <td>${glasses}</td>
    </tr>`;
  });

  document.querySelector("#calendar tbody").innerHTML = calendarRows;
}

// ✅ Edit a day manually
function editDay(day) {
  let current = history[day] || 0;
  let input = prompt(`Enter glasses of water for ${day}:`, current);
  if (input !== null) {
    let value = parseInt(input);
    if (!isNaN(value) && value >= 0) {
      history[day] = value;
      localStorage.setItem("waterHistory", JSON.stringify(history));
      renderCalendar();
      renderChart();
    } else {
      alert("⚠️ Please enter a valid number!");
    }
  }
}

// ✅ Avatar generator
function generateAvatar() {
  const gender = document.getElementById("genderSelect").value;
  const hairColor = document.getElementById("hairColorSelect").value;

  let avatar = "";
  if (gender === "girl") {
    if (hairColor === "black") avatar = "👧🖤";
    else if (hairColor === "blonde") avatar = "👧💛";
    else if (hairColor === "brown") avatar = "👧🤎";
    else if (hairColor === "red") avatar = "👧❤️";
  } else {
    if (hairColor === "black") avatar = "👦🖤";
    else if (hairColor === "blonde") avatar = "👦💛";
    else if (hairColor === "brown") avatar = "👦🤎";
    else if (hairColor === "red") avatar = "👦❤️";
  }

  localStorage.setItem("customAvatar", avatar);
  document.getElementById("avatarPreview").textContent = avatar;
}

// ✅ Show saved avatar
window.onload = function () {
  const savedAvatar = localStorage.getItem("customAvatar");
  if (savedAvatar) {
    document.getElementById("avatarPreview").textContent = savedAvatar;
  }
};