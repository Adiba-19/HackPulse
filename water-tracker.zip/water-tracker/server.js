const express = require('express');
const Database = require('better-sqlite3');
const path = require('path');
const bodyParser = require('body-parser');

const app = express();
const db = new Database('database.db');

// Middleware
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// Create tables
db.prepare(`CREATE TABLE IF NOT EXISTS intake (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  date TEXT,
  glasses INTEGER
)`).run();

db.prepare(`CREATE TABLE IF NOT EXISTS avatar (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  gender TEXT,
  hair_color TEXT
)`).run();

// Save water intake
app.post('/save-intake', (req, res) => {
  const today = new Date().toLocaleDateString();
  const glasses = req.body.glasses || 0;
  db.run(`INSERT INTO intake (date, glasses) VALUES (?, ?)`, [today, glasses], err => {
    if (err) return res.status(500).send("Error saving intake");
    res.json({ status: 'success' });
  });
});

// Get last 7 days
app.get('/get-history', (req, res) => {
  db.all(`SELECT date, glasses FROM intake ORDER BY date DESC LIMIT 7`, (err, rows) => {
    if (err) return res.status(500).send("Error fetching history");
    res.json(rows);
  });
});

// Save avatar
app.post('/save-avatar', (req, res) => {
  const { gender, hairColor } = req.body;
  db.run(`INSERT INTO avatar (gender, hair_color) VALUES (?, ?)`, [gender, hairColor], err => {
    if (err) return res.status(500).send("Error saving avatar");
    res.json({ status: 'avatar saved' });
  });
});

// Start server
app.listen(3000, () => {
  console.log('🚀 Server running at http://localhost:3000');
});